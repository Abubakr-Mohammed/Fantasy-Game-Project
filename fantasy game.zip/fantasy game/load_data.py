# Update '' to list all students contributing to the team work
__author__ = 'Anna Romazanova 101290780, Abubakr Mohammed 101287262, Dyson Jumpah 101265051, Eyad Elwahsh 101286337'

# Update '' with your team (e.g. T102)
__team__ = 'T15'

#==========================================#
# Place your character_occupation_list function after this line

def occupation_list(file_name: str, occupation: str) -> list:
    """Returns a list of characters (stored as a dictionary) in accordance with the occupation provided as an input parameter.
    
    Preconditions: file_name == 'characters-mat.csv'  &  type(occupation) == str.
    
    >>>occupation_list('characters-mat.csv', 'AT')
    [{'Strength': 15, 'Weapon': 'Dagger', 'Agility': 9, 'Stamina': 0.61, 'Intelligence': 7, 'Luck': 5, 'Armor': 10, 'Personality': 18}, {'Strength': 11, 'Weapon': 'Club', 'Agility': 7, 'Stamina': 0.67, 'Intelligence': 10, 'Luck': 9, 'Armor': 10, 'Personality': 9}, {'Strength': 17, 'Weapon': 'Dagger', 'Agility': 7, 'Stamina': 0.61, 'Intelligence': 7, 'Luck': 8, 'Armor': 10, 'Personality': 12}, {further elements}...]
    
    >>>occupation_list('characters-mat.csv', 'UKR')
    []
    
    >>>occupation_list('characters-mat.csv', 'M')
    [{'Strength': 10, 'Weapon': 'Club', 'Agility': 5, 'Stamina': 0.44, 'Intelligence': 8, 'Luck': 15, 'Armor': 9, 'Personality': 10}, {'Strength': 17, 'Weapon': 'Dagger', 'Agility': 8, 'Stamina': 0.39, 'Intelligence': 13, 'Luck': 8, 'Armor': 10, 'Personality': 7}, {'Strength': 13, 'Weapon': 'Dagger', 'Agility': 9, 'Stamina': 0.72, 'Intelligence': 8, 'Luck': 11, 'Armor': 10, 'Personality': 14}, {further elements} ...]
    
    """
    File = open(file_name, 'r')
    characters_occupation_list = []
    
    for line in File:
        symbol = line.strip().split(",")
        if symbol[0] == occupation:
            dictionary = {}
            dictionary["Strength"] = int(symbol[1])
            dictionary["Weapon"] = str(symbol[2])
            dictionary["Agility"] = int(symbol[3])
            dictionary["Stamina"] = float(symbol[4])
            dictionary["Intelligence"] = int(symbol[5])
            dictionary["Luck"] = int(symbol[6])
            dictionary["Armor"] = int(symbol[7])
            dictionary["Personality"] = int(symbol[8])
            characters_occupation_list.append(dictionary)

    return characters_occupation_list

#==========================================#
# Place your personality_list function after this line

def personality_list(file_name: str, personality_range: tuple) -> list:
    """Returns a list of characters (stored as a dictionary) whose personality falls between the minimum and maximum values, inclusive, that were provided as an input parameter.
    
    Preconditions: file_name == 'characters-mat.csv'  &  type(personality_range) == tuple.
    
    >>>personality_list('characters-mat.csv', (10, 13))
    [{'Occupation': 'AT', 'Strength': 17, 'Weapon': 'Dagger', 'Agility': 7, 'Stamina': 0.61, 'Intelligence': 7, 'Luck': 8, 'Armor': 10}, {'Occupation': 'AT', 'Strength': 14, 'Weapon': 'Staff', 'Agility': 2, 'Stamina': 0.78, 'Intelligence': 5, 'Luck': 8, 'Armor': 8}, {'Occupation': 'AT', 'Strength': 15, 'Weapon': 'Dagger', 'Agility': 11, 'Stamina': 0.94, 'Intelligence': 9, 'Luck': 10, 'Armor': 11}, {another element}, ...]
    
    >>>personality_list('characters-mat.csv', (100, 200))
    []
    
    >>>personality_list('characters-mat.csv', (6, 19))
    [{'Occupation': 'AT', 'Strength': 15, 'Weapon': 'Dagger', 'Agility': 9, 'Stamina': 0.61, 'Intelligence': 7, 'Luck': 5, 'Armor': 10}, {'Occupation': 'AT', 'Strength': 11, 'Weapon': 'Club', 'Agility': 7, 'Stamina': 0.67, 'Intelligence': 10, 'Luck': 9, 'Armor': 10}, {'Occupation': 'AT', 'Strength': 17, 'Weapon': 'Dagger', 'Agility': 7, 'Stamina': 0.61, 'Intelligence': 7, 'Luck': 8, 'Armor': 10}, {another element}, ...]
    
    """

    line_count = 0
    personality_list = []
    File = open(file_name, 'r')
    for line in File:
        symbol = line.strip("\n").split(",")
    
        if line_count == 0:
            line_count += 1
    
        elif line_count != 0:
            if personality_range[0] <= int(symbol[8]) <= personality_range[1]:
                dictionary = {}
                dictionary["Occupation"] = str(symbol[0])
                dictionary["Strength"] = int(symbol[1])
                dictionary["Weapon"] = str(symbol[2])
                dictionary["Agility"] = int(symbol[3])
                dictionary["Stamina"] = float(symbol[4])
                dictionary["Intelligence"] = int(symbol[5])
                dictionary["Luck"] = int(symbol[6])
                dictionary["Armor"] = int(symbol[7])
                personality_list.append(dictionary)

    return personality_list

#==========================================#
# Place your stamina_list function after this line

def stamina_list(file_name: str, stamina_value: float) -> list:
    """Returns a list of characters (stored as a dictionary) whose stamina is greater than the value provided as an input parameter.
    
    Preconditions: file_name == 'characters-mat.csv'  &  type(stamina_value) == float.

    >>>stamina_list('characters-mat.csv', 0.5)
    [{'Occupation': 'AT', 'Strength': 15, 'Weapon': 'Dagger', 'Agility': 9, 'Intelligence': 7, 'Luck': 5, 'Armor': 10, 'Personality': 18}, {'Occupation': 'AT', 'Strength': 11, 'Weapon': 'Club', 'Agility': 7, 'Intelligence': 10, 'Luck': 9, 'Armor': 10, 'Personality': 9}, {'Occupation': 'AT', 'Strength': 17, 'Weapon': 'Dagger', 'Agility': 7, 'Intelligence': 7, 'Luck': 8, 'Armor': 10, 'Personality': 12}, {another element} ...]
    
    >>>stamina_list('characters-mat.csv', 0.44)
    [{'Occupation': 'AT', 'Strength': 15, 'Weapon': 'Dagger', 'Agility': 9, 'Intelligence': 7, 'Luck': 5, 'Armor': 10, 'Personality': 18}, {'Occupation': 'AT', 'Strength': 11, 'Weapon': 'Club', 'Agility': 7, 'Intelligence': 10, 'Luck': 9, 'Armor': 10, 'Personality': 9}, {'Occupation': 'AT', 'Strength': 17, 'Weapon': 'Dagger', 'Agility': 7, 'Intelligence': 7, 'Luck': 8, 'Armor': 10, 'Personality': 12}, {another element}, ...]
    
    >>>stamina_list('characters-mat.csv', 19)
    []
    """
    line_count = 0
    final_list = []
    File = open(file_name, 'r')
    for line in File:
        symbol = line.strip("\n").split(",")

        if line_count == 0:
            line_count += 1

        elif line_count != 0:
            if symbol[4] > str(stamina_value):
                dictionary = {}
                dictionary["Occupation"] = str(symbol[0])
                dictionary["Strength"] = int(symbol[1])
                dictionary["Weapon"] = str(symbol[2])
                dictionary["Agility"] = int(symbol[3])
                dictionary["Intelligence"] = int(symbol[5])
                dictionary["Luck"] = int(symbol[6])
                dictionary["Armor"] = int(symbol[7])
                dictionary["Personality"] = int(symbol[8])
                final_list.append(dictionary)
            
    return final_list

#==========================================#
# Place your weapon_list function after this line

def weapon_list(file_name: str, weapon_value: str) -> list:
    """Returns a list of characters (stored as a dictionary) that their weapon is provided as the input parameters.
    
    Preconditions: file_name == 'characters-mat.csv'  &  type(weapon_value) == str.
    
    >>>weapon_list('characters-mat.csv', 'Staff')
    [{'Occupation': 'AT', 'Strength': 14, 'Agility': 2, 'Stamina': 0.78, 'Intelligence': 5, 'Luck': 8, 'Armor': 8, 'Personality': 11}, {'Occupation': 'AT', 'Strength': 9, 'Agility': 9, 'Stamina': 0.5, 'Intelligence': 15, 'Luck': 3, 'Armor': 10, 'Personality': 9}, {another element}, ...]
     
    >>>weapon_list('characters-mat.csv', 'Carleton')
    []
     
    >>>weapon_list('characters-mat.csv', 'Club')
    [{'Occupation': 'AT', 'Strength': 11, 'Agility': 7, 'Stamina': 0.67, 'Intelligence': 10, 'Luck': 9, 'Armor': 10, 'Personality': 9}, {'Occupation': 'AT', 'Strength': 18, 'Agility': 11, 'Stamina': 0.83, 'Intelligence': 11, 'Luck': 6, 'Armor': 11, 'Personality': 4}, {another element}, ...]
    
    """
    weapon_list = []
    file = open(file_name, "r")
    for line in file:
        word_list = line.strip("\n").split(",")
        if word_list[2] == weapon_value:
            weaponDict = {}
            weaponDict['Occupation'] = word_list[0]
            weaponDict['Strength'] = int(word_list[1])
            weaponDict['Agility'] = int(word_list[3])
            weaponDict['Stamina'] = float(word_list[4])
            weaponDict['Intelligence'] = int(word_list[5])
            weaponDict['Luck'] = int(word_list[6])
            weaponDict['Armor'] = int(word_list[7])
            weaponDict['Personality'] = int(word_list[8])
            weapon_list.append(weaponDict)

    return weapon_list

#==========================================#
# Place your load_data function after this line

def load_data(file_name: str, info: tuple) -> list:
    """Returns a list of characters (stored as a dictionary) where the keys of the dictionary are the labels for all attributes in the spreadsheet except for the attribute in the first item of the tuple.
    
    Preconditions: file_name == 'characters-mat.csv'  &  type(info) == tuple.

    >>> load_data('characters-mat.csv', ('Weapon', 'Staff'))
    
    [{'Occupation': 'AT', 'Strength': 14, 'Agility': 2, 'Stamina': 0.78,
    'Intelligence': 5, 'Luck': 8, 'Armor': 8, 'Personality': 11}, ...]
    
    >>> load_data('characters-mat.csv', ('All', 100))
    [{'Occupation': 'AT', 'Strength': 15, 'Weapon': 'Dagger', 'Agility': 9,
    'Stamina': 0.61, 'Intelligence': 7, 'Luck': 5, 'Armor': 10,
    'Personality': 18}, {'Occupation': 'AT', 'Strength': 11, 'Weapon': 'Club', 'Agility': 7,
    'Stamina': 0.67, 'Intelligence': 10, 'Luck': 9, 'Armor': 10,
    'Personality': 9}, ...]
      
    >>> load_data('characters-mat.csv', ('Occupation', 'AT'))
    [{'Strength': 15, 'Weapon': 'Dagger', 'Agility': 9, 'Luck': 5, 'Intelligence': 7, 'Stamina': 0.61, 'Armor': 10, 
    'Personality': 18}...]
    
        """
        
    if info[0] == 'Occupation':
        return(occupation_list(file_name, info[1]))

    if info[0] == 'Personality':
        return(personality_list(file_name, info[1]))

    if info[0] == 'Stamina':
        return(stamina_list(file_name, info[1]))

    if info[0] == 'Weapon':
        return(weapon_list(file_name, info[1]))

    if info[0] == 'All':

        pokemon_list = []
        file = open(file_name, "r")

        for line in file:
            word_list = line.strip("\n").split(",")

            if word_list[0] != 'Occupation':
                pokemonDict = {}
                pokemonDict['Occupation'] = word_list[0]
                pokemonDict['Strength'] = int(word_list[1])
                pokemonDict['Weapon'] = str(word_list[2])
                pokemonDict['Agility'] = int(word_list[3])
                pokemonDict['Luck'] = int(word_list[6])
                pokemonDict['Intelligence'] = int(word_list[5])
                pokemonDict['Stamina'] = float(word_list[4])
                pokemonDict['Armor'] = int(word_list[7])
                pokemonDict['Personality'] = int(word_list[8])
                pokemon_list.append(pokemonDict)

        return pokemon_list
    
    else:
        return []
    
#==========================================#
# Place your add_average function after this line

def calculate_health(health_list: list) -> list:
    """Returns an original list with a new function Health.
    
    Precondition: Values for Strength, Agility, Luck, Intelligence, Armor, are numbers
    
    >>> calculate_health([{'Strength': 13, 'Agility': 2, 'Stamina': 0.7, 'Personality': 7, 'Intelligence': 8, 'Luck': 6, 'Armor': 8, 'Weapon': 'Staff'}])
   
    [{'Strength': 13, 'Agility': 2, 'Stamina': 0.7, 'Personality': 7, 'Intelligence': 8, 'Luck': 6, 'Armor': 8, 'Weapon': 'Staff', 'Health': 116.0}]
    
    """
    new_list = []
    for i in range(len(health_list)):
            new_dict = {}
            new_dict = health_list[i]
            strength = new_dict['Strength']
            agility = new_dict['Agility']
            luck= new_dict['Luck']
            intelligence = new_dict['Intelligence']
            armor = new_dict['Armor']
    
            Health = (strength + agility + luck + intelligence) * (armor/2)
            new_dict['Health'] = round(Health, 1)
            new_list.append(new_dict)
    
    return new_list
