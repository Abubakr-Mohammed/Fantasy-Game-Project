# ECOR 1042 Lab 6 - Individual submission for text_UI

# Update "" with your name (e.g., Rami Sabouni)
__author__ = "Anna Romazanova"

# Update "" with your student number (e.g., 100100100)
__student_number__ = "101290780"

# Update "" with your team (e.g. T-102, use the notation provided in the example)
__team__ = "T15"

#==========================================#
# Place your script for your text_UI after this line

from load_data import *
from sort import *
from curve_fit import *
from histogram import *

def display_commands():
    print('The available commands are:\n    L)oad Data\n    S)ort Data\n    C)urve Fit\n    H)istogram\n    E)xit\n')
    command = input("Please type your command: ")
    data = [] 
        
    while command.upper() != 'E':
        
        while command.upper() not in ['L', 'S', 'C', 'H', 'E']:
            print("Invalid command.\n")
            display_commands()
            
        if command.upper() == 'L':
             
            file_name = input('Please enter the name of the file: ') #should be "characters-test.csv"
            attribute = input('Please enter the attribute to use as a filter: ')
            
            while attribute not in ["Occupation", "Personality", "Stamina", "Weapon", "All"]:
                attribute = input("Invalid attribute, please try again: ")
                
            if attribute == 'All':
                data = calculate_health(load_data(file_name, (attribute, 19)))  # the last number (here: '19') doesn't matter since when 'All' is called in the 'load_data'function, any number can be put
                
            else:
                if attribute == "Stamina":
                    value = float(input('Please enter the value of the attribute: ')) #user should enter a NUMBER, otherwise the program will throw an Error!!!   
                elif attribute == "Personality":
                    value = eval(input('Please enter the value of the attribute: '))  #user should enter 2 NUMBERS, otherwise the program will throw an Error!!!  
                else:
                    value = input('Please enter the value of the attribute: ')
                    
                data = calculate_health(load_data(file_name, (attribute, value)))        
            
            if data != []:
                print("Data loaded\nProgram is running again\n")
            else:
                print('File NOT loaded! Please, load a file first.\n')
            display_commands()
        
                
        elif command.upper() == 'S':
            
            sorting_attribute = input("Please enter the attribute you want to use for sorting:\n'Luck', 'Armor', 'Strength', 'Health'\n: ")
            
            while sorting_attribute not in ["Armor", "Strength", "Luck", "Health"]:
                sorting_attribute = input("Invalid sorting attribute, please try again: ")
                
            order = input("Ascending (A) or Descending (D) order: ")
            
            list_of_dictionaries = calculate_health(load_data('characters-test.csv', ('All', 19)))
            
            data = sort(list_of_dictionaries, order, sorting_attribute)
            
            if order != "A" and order != "D":
                print("Data not sorted, please try again.\n")
                display_commands()
                
            if data != []:
                show_data = input("Data Sorted. Do you want to display the data?: ")
                
                while show_data != "Y" and show_data != "N":
                    show_data = input("Please enter either 'Y' for 'Yes' or 'N' for 'No': ")
                if show_data == 'Y':
                    print(data, "\n")
                    display_commands()                        
                    
                if show_data == 'N':
                    print("\n")
                    display_commands()
            else:
                print('File NOT loaded! Please, load a file first.\n')
                display_commands()            
     
     
        elif command.upper() == 'C':
            
            attribute = input('Please enter the attribute you want to use to find the best fit for Health: ')
            degree = int(input('Please enter the order of the polynomial to be fitted: '))
            list_of_dictionaries = calculate_health(load_data('characters-test.csv', ('All', 19)))
            
            data = curve_fit(list_of_dictionaries, attribute, degree)
            if data == []:
                print('File not loaded! Please, load a file first.\n')
            else:
                print(data, "\n")
            display_commands()
        
            
        elif command.upper() == 'H':
            
            attribute = input('Please enter the attribute you want to use for plotting: ')
            data = histogram(calculate_health(load_data('characters-test.csv', ('All', 19))), attribute)
            if data == []:
                print('File not loaded! Please, load a file first.\n')
            else:
                print(data, "\n")
            display_commands()
                   
    print("Program ended, goodbye!")
    
display_commands()