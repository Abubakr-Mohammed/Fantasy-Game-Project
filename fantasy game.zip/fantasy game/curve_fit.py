# ECOR 1042 Lab 6 - Individual submission for curve_fit function

# Remember to include docstring and type annotations for your functions

# Update "" with your name (e.g., Rami Sabouni)
__author__ = "Abubakr Mohammed"

# Update "" with your student number (e.g., 100100100)
__student_number__ = "101287262"

# Update "" with your team (e.g. T-102, use the notation provided in the example)
__team__ = "T-015"

#==========================================#
# Place your curve_fit function after this line
import numpy as np
def curve_fit(characters: list, string: str, x: int) -> str:
    """return a string representation of the equation of the best fit for the average of Health
    
    Precondition: len(characters) > 0, and x > 0.
    
    Examples
    >>>curve_fit([{'Strength': 23, 'Health': 30},{'Strength': 22, 'Health': 20},{'Strength': 1, 'Health': 30}], 'Strength', 3)
    '0.48x^2 + -1.1e+01x + 4.1e+01'
    >>>curve_fit([{'Strength': 19, 'Health': 33},{'Strength': 10, 'Health': 14},{'Strength': 4, 'Health': 14}], 'Strength', 2)
    '0.141x^2 + -1.97x + 19.6'
    >>>curve_fit([{'Strength': 25, 'Health': 35},{'Strength': 10, 'Health': 15},{'Strength': 12, 'Health': 24}], 'Strength', 4)
    '-0.244x^2 + 9.86x + -59.2'
    """
    possible_strings = ['STRENGTH','AGILITY','STAMINA','PERSONALITY','INTELLIGENCE','LUCK','ARMOR'] 
    char_database = {}  
    character_val = []
    string = string.upper()
    if string not in possible_strings: 
        return("invalid input please try again")    
    else:
        for word in characters:
            key = word[string.title()]
            if key not in char_database: 
                char_database[key] = [] 
                char_database[key].append(word['Health']) 
            else:
                char_database[key].append(word['Health']) 
    for val in char_database.keys():   
        g = 0
        for length in char_database[val]: 
            g += length
        
        character_val.append(g/len(char_database[val]))
                     
    z = list(char_database.keys()) 
    y = character_val
    
    help = len(z)
    deg = x+1
    if help <= deg: 
        deg = len(z) - 1 
    else: 
        deg = x 
    
    plot = np.polyfit(z, y, deg)
    
    if deg == 1: 
        return "{0:0.3}x + {1:0.3}".format(plot [0], plot[1])
        
    elif deg == 2: 
        return "{0:0.3}x^2 + {1:0.3}x + {2:0.3}".format(plot [0], plot [1], plot [2])
    
    elif deg == 3:  
        return "{0:0.3}x^2 + {1:0.3}x + {2:0.3} + {3:0.3} ".format(plot [0], plot [1], plot [2], plot[3])
        
    elif deg  == 4: 
        return "{0:0.3}x^2 + {1:0.3}x + {2:0.3} + {3:0.3} + {4:0.3} ".format(plot [0], plot [1], plot [2], plot[3], plot[4])
    
    elif deg == 5: 
        return "{0:0.3}x^2 + {1:0.3}x + {2:0.3} + {3:0.3} + {4:0.3} + {5:0.3} ".format(plot [0], plot [1], plot [2], plot[3], plot[4], plot[5])   
    
# Do NOT include a main script in your submission
