# ECOR 1042 Lab 6 - Individual submission for histogram

# Remember to include docstring and type annotations for your functions

# Update "" with your name (e.g., Rami Sabouni)
__author__ = "Eyad_Elwahsh"

# Update "" with your student number (e.g., 100100100)
__student_number__ = "101286337"

# Update "" with your team (e.g. T-102, use the notation provided in the example)
__team__ = "T-15"

#==========================================#
# Place your histogram function after this line
import matplotlib.pyplot as plt
import numpy
import scipy


def histogram(list_char: list[dict], attribute: str):
    """
    Return a plot of a histogram that plots the given character information using the input attribute as the graphing parameters.

    Preconditions: None

    Examples:
    >>>histogram([{'Strength': 7, 'Health': 11, 'Weapon': 'Club'}, {'Strength': 2, 'Health': 16, 'Weapon': 'Staff'}, {'Strength': 2, 'Health': 13, 'Weapon': 'Dagger'}], 'Strength')
    None
    >>>histogram([{'Strength': 5, 'Health': 3, 'Weapon': 'Spear'}, {'Strength': 2, 'Weapon': 'Club', 'Health': 4}, {'Strength': 3, 'Health': 5, 'Weapon': 'Sling'}], 'Health')
    None     
    >>>histogram([{'Strength': 5, 'Health': 11, 'Agility': 10}, {'Strength': 5, 'Health': 10, 'Agility': 3}, {'Agility': 5, 'Health': 9, 'Strength': 8}], 'Agility')
    None
    """
    start = {}

    for char_dict in list_char:
        char_input = char_dict[attribute]

        if type(char_input) == float:
            char_input = int(char_input)
        if char_input not in start:
            start[char_input] = 0
        start[char_input] += 1

    fig_one = plt.figure(1, (5, 5))
    plt.title(f'{attribute} Histogram')
    plt.xlabel(attribute)
    plt.ylabel(f"Number of Characters Listed With {attribute} Key")
    plt.bar(x=start.keys(), height=start.values())
    plt.show()

# Do NOT include a main script in your submission
