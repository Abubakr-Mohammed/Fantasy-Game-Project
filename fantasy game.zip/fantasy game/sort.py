# ECOR 1042 Lab 5 - Team submission
# Remember to include docstring and type annotations for your functions

# Update "" to list all students contributing to the team work
__author__ = "Anna Romazanova 101290780, Abubakr Mohammed 101287262, Dyson Jumpah 101265051, Eyad Elwahsh 101286337"

# Update "" with your team (e.g. T102)
__team__ = "T15"

#==========================================#
# Place your sort_strength_selection function after this line

def sort_strength_selection(dict_list: list[dict], letter: str) -> list[dict]:
    """Return a sorted list of dictionaries by the "Strength" attribute and indicated order ('A' for ascending or 'D' for descending) using selection sort algorithm. If “Strength” is not a key in the dictionary, the function prints a message stating the key is not in the dictionary and returns the original dict_list.
    
    Preconditions: type(dict_list) == list & letter == "A" or "D".
    
    >>>sort_strength_selection([{'Occupation': 'EB', 'Strength': 13}, {'Occupation': 'H', 'Strength': 11}], "A")
    [{'Occupation': 'H', 'Strength': 11}, {'Occupation': 'EB', 'Strength': 13}]
    
    
    >>>sort_strength_selection([{'Occupation': 'EB', 'Strength': 13}, {'Occupation': 'H', 'Strength': 11}, {'Occupation': 'DE', 'Strength': 9}], "D")
    [{'Occupation': 'EB', 'Strength': 13}, {'Occupation': 'H', 'Strength': 11}, {'Occupation': 'DE', 'Strength': 9}]
    
    
    >>>sort_strength_selection([{'Occupation': 'EB', 'Health': 62.37}, {'Occupation': 'H', 'Health': 62.71}], "A")
    "Strength" is not in dictionary as key.
    [{'Occupation': 'EB', 'Health': 62.37}, {'Occupation': 'H', 'Health': 62.71}]
    """
    
    check = 0
    for every_dict in dict_list:
            if every_dict.get("Strength", "None") == "None":
                    check += 1
            else:
                    check = check
                    
    if check == 0 and letter == "A":
            for i in range(len(dict_list)):
                    minimum = i
                    for j in range(i + 1, len(dict_list)):
                            if dict_list[minimum]["Strength"] > dict_list[j]["Strength"]:
                                minimum = j
                    dict_list[i], dict_list[minimum] = dict_list[minimum], dict_list[i]
        
        
    elif check == 0 and letter == "D":
            for i in range(len(dict_list)):
                    maximum = i
                    for j in range(i + 1, len(dict_list)):
                        if dict_list[maximum]["Strength"] < dict_list[j]["Strength"]:
                                    maximum = j
                    dict_list[i], dict_list[maximum] = dict_list[maximum], dict_list[i]

            
    elif check == 0 and (letter != "A" or "D"):
            print("Invalid letter, please input either 'A' for Ascending or 'D' for Descending.")
            
    else:
            print('"Strength" is not in dictionary as key.')
          
    return dict_list

#==========================================#
# Place your sort_luck_bubble function after this line

def sort_luck_bubble(arr: list[dict], order: str) -> list[dict]:
    """Return a sorted list of dictionaries according to the "Luck" attribute and indicated order ('A' for ascending or 'D' for descending) using the bubble sort algorithm. If “Luck” is not a key in the dictionary, the function should print a message stating the key is not in the dictionary and return the original arr.

    Preconditions: order == "A" or "D"  &  type(arr) == list.
    
    >>> sort_luck_bubble([{'Occupation': 'EB', 'Luck': 9}, {'Occupation':'H', 'Luck': 12}], "D")
    [{'Occupation': 'H', 'Luck': 12}, {'Occupation': 'EB', 'Luck': 9}]
    
    >>> sort_luck_bubble([{'Occupation': 'EB', 'Luck': 9}, {'Occupation':'H', 'Luck': 12}], "A")
    [{'Occupation': 'EB', 'Luck': 9}, {'Occupation': 'H', 'Luck': 12}]

    >>> sort_luck_bubble([{'Occupation': 'EB'}, {'Occupation': 'M'}], "D")
    "Luck" key is not present.
    [{'Occupation': 'EB'},{'Occupation': 'M'}]
    """
    for every_dict in arr:
        keys = every_dict.keys()
        if "Luck" not in keys:
            print('"Luck" key is not present.')
            return arr

    if order == "A":
        swap = True
        while swap:
            swap = False
            for i in range(len(arr) - 1):
                if arr[i]["Luck"] > arr[i + 1]["Luck"]:
                    aux = arr[i]
                    arr[i] = arr[i + 1]
                    arr[i + 1] = aux
                    swap = True

    elif order == 'D':
        swap = True
        while swap:
            swap = False
            for i in range(len(arr) - 1):
                if arr[i]["Luck"] < arr[i + 1]["Luck"]:
                    aux = arr[i + 1]
                    arr[i + 1] = arr[i]
                    arr[i] = aux
                    swap = True

    elif order != 'A' or 'D':
        raise ValueError('Order must be either "A" or "D".')

    return arr

#==========================================#
# Place your sort_health_bubble function after this line

def sort_health_bubble(list_dict: list[dict], order: str) -> list[dict]:
    """Return a sorted list of dictionaries according to the "Health" attribute and indicated order ('A' for ascending or 'D' for descending) using the bubble sort algorithm. If “Health” is not a key in the dictionary, the function should print a message stating the key is not in the dictionary and return the original list_dict.

    Preconditions: order == "A" or "D"  &  type(list_dict) == list. 

    >>>sort_health_bubble([{'Occupation': 'EB', 'Health': 62.37}, {'Occupation': 'H', 'Health': 62.71}], "A")
    [{'Occupation': 'EB', 'Health': 62.37}, {'Occupation': 'H', 'Health': 62.71}]
    
    >>>sort_health_bubble([{'Occupation': 'EB', 'Health': 62.37}, {'Occupation': 'H', 'Health': 62.71}], "D")
    [{'Occupation': 'H', 'Health': 62.71}, {'Occupation': 'EB', 'Health': 62.37}]
     
    >>>sort_health_bubble([{'Occupation':'EB'}, {'Occupation': 'M'}], "D")
    "Health" key is not present.
    [{'Occupation': 'EB'}, {'Occupation': 'M'}]

    """
    swap = True
    health_in_list = False
    
    for dictionary in list_dict:
        if ("Health" in dictionary) == True:
            health_in_list = True
            
    if health_in_list == False:
        print('"Health" key is not present.')
        return list_dict
    
    else:  # if health_in_list == True (after that for loop)
        
        while swap:
            swap = False
            if order == "A":
                for i in range(len(list_dict) - 1):
                    if list_dict[i]["Health"] > list_dict[i + 1]["Health"]:
                        aux = list_dict[i]
                        list_dict[i] = list_dict[i + 1]
                        list_dict[i + 1] = aux
                        swap = True

            elif order == "D":
                for i in range(len(list_dict) - 1):
                    if list_dict[i]["Health"] < list_dict[i + 1]["Health"]:
                        aux = list_dict[i]
                        list_dict[i] = list_dict[i + 1]
                        list_dict[i + 1] = aux
                        swap = True
                        
            elif order != "A" or "D":
                print("Invalid input, please enter either 'A' or 'D'.")
            
    return list_dict

#==========================================#
# Place your sort_armor_insertion function after this line

def sort_armor_insertion(dict_list: list[dict], order: str) -> list[dict]:
    """Return a sorted list of dictionaries by the "Armor" attribute and indicated order ('A' for ascending or 'D' for descending) using insertion sort algorithm. If “Armor” is not a key in the dictionary, the function prints a message stating the key is not in the dictionary and returns the original list.
    
    Preconditions: type(dict_list) == list & order == "A" or "D".
    
    >>>sort_armor_insertion([{'Occupation': 'EB', 'Armor': 11}, {'Occupation': 'H', 'Armor': 10}], "D")
    [{'Occupation': 'EB', 'Armor': 11}, {'Occupation': 'H', 'Armor': 10}]
    
    >>>sort_armor_insertion([{'Occupation': 'EB'}, {'Occupation': 'M'}], "D")
    "Armor" key is not present.
    [{'Occupation': 'EB'}, {'Occupation': 'M'}]
    
    >>>sort_armor_insertion([{'Occupation': 'EB', 'Armor': 5}, {'Occupation': 'H', 'Armor': 12}], "A")
    [{'Occupation': 'H', 'Armor': 5}, {'Occupation': 'EB', 'Armor': 12}]    
    """
    for i in range(1, len(dict_list)):

        if "Armor" in dict_list[i]:
            i_key = dict_list[i]["Armor"]
            j = i - 1
            
            while j >= 0:
                if "Armor" in dict_list[j]:
                    j_key = dict_list[j]["Armor"]
                    
                    if order == 'D' and j_key < i_key:
                        dict_list[i], dict_list[j] = dict_list[j], dict_list[i]
                        j -= 1                    

                    elif order == 'A' and j_key > i_key:
                        dict_list[i], dict_list[j] = dict_list[j], dict_list[i]
                        j -= 1
                        
                    else:
                        break
                    
                else:
                    print("'Armor' key is not present.")
                    return dict_list
        #else:
            #print("'Armor' key is not present.")
            #return dict_list        
        
    if order != "A" and order != "D":
        print("Invalid input, please enter either 'A' or 'D'.")   

    return dict_list

#==========================================#
# Place your sort function after this line

def sort(dict_list: list[dict], sorting_string: str, string: str) -> list[dict]:
    """Return a sorted list of dictionaries according to the input parameters using previously implemented functions.
    
    Preconditions: type(dict_list) == list & sorting_string == "A" or "D"  & string == "Strength" or "Luck" or "Health" or "Armor".
    
    >>> sort([{'Occupation': 'EB', 'Strength': 13}, {'Occupation': 'H', 'Strength': 11}], "D", "Strength")
    [{'Occupation': 'EB', 'Strength': 13}, {'Occupation': 'H', 'Strength': 11}]
    
    >>> sort([{'Occupation': 'EB', 'Strength': 13}, {'Occupation': 'H', 'Strength': 11}], "A", "Stamina")
    Cannot be sorted by 'Stamina' since its value is invalid.
    [{'Occupation': 'EB', 'Strength': 13}, {'Occupation': 'H', 'Strength': 11}]
    
    >>> sort([{'Occupation': 'EB', 'Strength': 13}, {'Occupation': 'H', 'Strength': 11}], "A", "Health")
    "Health" key is not present.
    [{'Occupation': 'EB', 'Strength': 13}, {'Occupation': 'H', 'Strength': 11}]
    """
    
    if string == "Strength":
        return sort_strength_selection(dict_list, sorting_string)
    elif string == "Luck":
        return sort_luck_bubble(dict_list, sorting_string)
    elif string == "Health":
        return sort_health_bubble(dict_list, sorting_string)
    elif string == "Armor":
        return sort_armor_insertion(dict_list, sorting_string)
    else:
        print("Cannot be sorted by '" + string + "' since its value is invalid.")
        return dict_list

# Do NOT include a main script in your submission