# ECOR 1042 Lab 4 - team submission

# import check module here
import check

# import load_data module here
from load_data import *

# Update "" with your the name of the active members of the team
__author__ = "Anna Romazanova 101290780, Abubakr Mohammed 101287262, Eyad Elwahsh 101286337"

# Update "" with your student number (e.g., 100100100)

# Update "" with your team (e.g. T-102, use the notation provided in the example)
__team__ = "T-15"

#==========================================#

# Place test_return_list function here

def test_return_list():
    
    #test that occupation_list returns a list (3 different test cases required)
    
    check.equal(isinstance(occupation_list("characters-test.csv", "VF"), list), True)
    check.equal(isinstance(occupation_list("characters-test.csv", "DB"), list), True)
    check.equal(isinstance(occupation_list("characters-test.csv", "Carleton"), list), True)
    
    
    #test that personality_list returns a list (3 different test cases required)
    
    check.equal(isinstance(personality_list("characters-test.csv", (10, 13)), list), True)
    check.equal(isinstance(personality_list("characters-test.csv", (9, 12)), list), True)
    check.equal(isinstance(personality_list("characters-test.csv", (300, 2023)), list), True)


    #test that stamina_list returns a list (3 different test cases required)
    
    check.equal(isinstance(stamina_list("characters-test.csv", 11), list), True)
    check.equal(isinstance(stamina_list("characters-test.csv", 0.83), list), True)
    check.equal(isinstance(stamina_list("characters-test.csv", 0.6), list), True)     
    

    #test that weapon_list returns a list (3 different test cases required)

    check.equal(isinstance(weapon_list("characters-test.csv", "Dagger"), list), True) 
    check.equal(isinstance(weapon_list("characters-test.csv", "Staff"), list), True) 
    check.equal(isinstance(weapon_list("characters-test.csv", "Gun"), list), True)
    

    #test that load_data returns a list (6 different test cases required)

    check.equal(isinstance(load_data("characters-test.csv", ("Weapon", "Club")), list), True)

    check.equal(isinstance(load_data("characters-test.csv", ("All", 100)), list), True) 

    check.equal(isinstance(load_data("characters-test.csv", ("Personality", (10, 13))), list), True) 

    check.equal(isinstance(load_data("characters-test.csv", ("Something", 10)), list), True) 

    check.equal(isinstance(load_data("characters-test.csv", ('Occupation', 'AT')), list), True)

    check.equal(isinstance(load_data("characters-test.csv", ("Stamina", 0.39)), list), True)  
    

    #test that calculate_health returns a list (3 different test cases required)

    check.equal(isinstance(calculate_health([{'Strength': 13, 'Agility': 13, 'Stamina': 0.67, 'Personality': 8, 'Intelligence': 15, 'Luck': 12, 'Armor': 11, 'Weapon': 'Dart'}]), list), True) 

    check.equal(isinstance(calculate_health([{'Strength': 15, 'Agility': 9, 'Stamina': 0.39, 'Personality': 10,'Intelligence': 7, 'Luck': 9, 'Armor': 10, 'Weapon': 'Dagger'}]), list), True)

    check.equal(isinstance(calculate_health([{'Strength': 15, 'Agility': 11, 'Stamina': 0.94, 'Personality': 13, 'Intelligence': 9, 'Luck': 5, 'Armor': 11, 'Weapon': 'Dagger'}, {'Strength': 15, 'Agility': 11, 'Stamina': 0.78, 'Personality': 16, 'Intelligence': 9, 'Luck': 8, 'Armor': 11, 'Weapon': 'Dagger'}]), list), True)

    #check.summary()
#test_return_list()


# Place test_return_list_correct_length function here

def test_return_list_correct_length():
    
    #test that occupation_list returns a list with the correct length (3 different test cases required)
    
    check.equal(len(occupation_list("characters-test.csv", 'HG')), 4)
    check.equal(len(occupation_list("characters-test.csv", 'H')), 3)
    check.equal(len(occupation_list("characters-test.csv", 'Ukraine')), 0)    
    
    #test that personality_list returns a list with the correct length (3 different test cases required)
    
    check.equal(len(personality_list("characters-test.csv", (5, 10))), 12)
    check.equal(len(personality_list("characters-test.csv", (10, 15))), 17)
    check.equal(len(personality_list("characters-test.csv", (15, 20))), 0)    
    
    #test that stamina_list returns a list with the correct length (3 different test cases required)
    
    check.equal(len(stamina_list("characters-test.csv", 0.6)), 17)
    check.equal(len(stamina_list("characters-test.csv", 0.4)), 24)
    check.equal(len(stamina_list("characters-test.csv", 1)), 0)    
    
    #test that weapon_list returns a list with the correct length(3 different test cases required)
    
    check.equal(len(weapon_list("characters-test.csv", 'Spear')), 2)
    check.equal(len(weapon_list("characters-test.csv", 'Dart')), 1)
    check.equal(len(weapon_list("characters-test.csv", 'Flamenwerfer')), 0)    
    
    #test that load_data returns a list with the correct length (6 different test cases required)
    
    check.equal(len(load_data("characters-test.csv", ('Occupation', 'VF'))), 3)
    check.equal(len(load_data("characters-test.csv", ('Personality', (5, 15)))), 26)
    check.equal(len(load_data("characters-test.csv", ('Stamina', 0.7))), 7)
    check.equal(len(load_data("characters-test.csv", ('Weapon', 'Dagger'))), 5)
    check.equal(len(load_data("characters-test.csv", ('All', '0'))), 26)
    check.equal(len(load_data("characters-test.csv", ('UKR', '100'))), 0)    
    
    #test that calculate_health returns a list with the correct length (3 different test cases required)
    
    check.equal(len(calculate_health(load_data('characters-test.csv', ('All', 0)))), 26)
    check.equal(len(calculate_health(occupation_list("characters-test.csv", 'WA'))), 5)
    check.equal(len(calculate_health([])), 0)    
    
    #check.summary()
#test_return_list_correct_length()


#Place test_return_correct_dict_inside_list function here

def test_return_correct_dict_inside_list():
    
    # test that occupation_list returns a correct dictionary inside the list (3 different test cases required)
    
    check.equal(occupation_list("characters-test.csv", 'AT')[0],
                {'Strength': 17, 'Weapon': 'Club', 'Agility': 10, 'Stamina': 0.44, 'Intelligence': 17, 'Luck': 5, 'Armor': 10, 'Personality': 11})
    
    check.equal(occupation_list("characters-test.csv", 'M')[-1],
                {'Strength': 15, 'Weapon': 'Longsword', 'Agility': 9, 'Stamina': 0.61, 'Intelligence': 8, 'Luck': 11, 'Armor': 10, 'Personality': 5})

    check.equal(occupation_list('characters-test.csv', 'UKR'), [])
    
    
    # test that personality_list returns a correct dictionary inside the list (3 different test cases required)
    

    check.equal(personality_list("characters-test.csv", (10, 13))[1],
                {'Occupation': 'AT', 'Strength': 15, 'Weapon': 'Dagger', 'Agility': 9, 'Stamina': 0.39, 'Intelligence': 7, 'Luck': 9, 'Armor': 10})
    
    check.equal(personality_list("characters-test.csv", (5, 9))[-1],
                {'Occupation': 'WA', 'Strength': 12, 'Weapon': 'Club', 'Agility': 10, 'Stamina': 0.44, 'Intelligence': 8, 'Luck': 6, 'Armor': 10})

    check.equal(personality_list('characters-test.csv', (190, 200)), [])
    

    # test that stamina_list returns a correct dictionary inside the list  (3 different test cases required)

    check.equal(stamina_list("characters-test.csv", 0.39)[0],
                {'Occupation': 'AT', 'Strength': 17, 'Weapon': 'Club', 'Agility': 10, 'Intelligence': 17, 'Luck': 5, 'Armor': 10, 'Personality': 11})

    check.equal(stamina_list("characters-test.csv", 0.78)[-1],
                {'Occupation': 'VF', 'Strength': 14, 'Weapon': 'Dagger', 'Agility': 6, 'Intelligence': 7, 'Luck': 4, 'Armor': 9, 'Personality': 5})

    check.equal(stamina_list("characters-test.csv", 2023), [])
    

    # test that weapon_list returns a correct dictionary inside the list (3 different test cases required)

    check.equal(weapon_list("characters-test.csv", 'Dart'),
                [{'Occupation': 'EB', 'Strength': 13, 'Agility': 13, 'Stamina': 0.67, 'Intelligence': 15, 'Luck': 12, 'Armor': 11, 'Personality': 8}])

    check.equal(weapon_list("characters-test.csv", 'Club')[-1],
                {'Occupation': 'WA', 'Strength': 12, 'Agility': 10, 'Stamina': 0.44, 'Intelligence': 8, 'Luck': 6, 'Armor': 10, 'Personality': 9})
    
    check.equal(weapon_list("characters-test.csv", 'Bomb'), [])
    

    # test that load_data returns a correct dictionary inside the list (6 different test cases required)

    check.equal(load_data("characters-test.csv", ('Weapon', 'Staff'))[0],
                {'Occupation': 'AT', 'Strength': 8, 'Agility': 7, 'Stamina': 0.67, 'Intelligence': 8, 'Luck': 2, 'Armor': 10, 'Personality': 11})

    check.equal(load_data("characters-test.csv", ('Occupation', 'H'))[-1],
                {'Strength': 16, 'Weapon': 'Shortbow', 'Agility': 11, 'Stamina': 0.61, 'Intelligence': 9, 'Luck': 8, 'Armor': 11, 'Personality': 6})

    check.equal(load_data("characters-test.csv", ('Personality', (11, 14)))[2],
                {'Occupation': 'DB', 'Strength': 19, 'Weapon': 'Dagger', 'Agility': 10, 'Stamina': 0.44, 'Intelligence': 12, 'Luck': 11, 'Armor': 10})

    check.equal(load_data('characters-test.csv', ('Stamina', 0.3))[1],
                {'Occupation': 'AT', 'Strength': 15, 'Weapon': 'Dagger', 'Agility': 9, 'Intelligence': 7, 'Luck': 9, 'Armor': 10, 'Personality': 10})

    check.equal(load_data('characters-test.csv', ('All', 69))[4],
                {'Occupation': 'DB', 'Strength': 11, 'Weapon': 'Club', 'Agility': 4, 'Luck': 10, 'Intelligence': 8, 'Stamina': 0.61, 'Armor': 9, 'Personality': 11})
    
    check.equal(load_data('characters-test.csv',
                ('Carleton', 'Carleton')), [])
    

    # test that calculate_health returns a correct dictionary inside the list  (3 different test cases required)

    check.equal(calculate_health([{'Strength': 13, 'Agility': 3, 'Stamina': 0.5, 'Personality': 8, 'Intelligence': 7, 'Luck': 10, 'Armor': 8, 'Weapon': 'Staff'}]),
                    [{'Strength': 13, 'Agility': 3, 'Stamina': 0.5, 'Personality': 8, 'Intelligence': 7, 'Luck': 10, 'Armor': 8, 'Weapon': 'Staff', 'Health': 132.0}])
        
    check.equal(calculate_health([{'Strength': 15, 'Agility': 9, 'Stamina': 0.39, 'Personality': 10, 'Intelligence': 7, 'Luck': 9, 'Armor': 10, 'Weapon': 'Dagger'}]),
                    [{'Strength': 15, 'Agility': 9, 'Stamina': 0.39, 'Personality': 10, 'Intelligence': 7, 'Luck': 9, 'Armor': 10, 'Weapon': 'Dagger', 'Health': 200.0}])
        
    check.equal(calculate_health([{'Strength': 17, 'Agility': 10, 'Stamina': 0.44, 'Personality': 11, 'Intelligence': 17, 'Luck': 5, 'Armor': 10, 'Weapon': 'Staff'}]),
                    [{'Strength': 17, 'Agility': 10, 'Stamina': 0.44, 'Personality': 11, 'Intelligence': 17, 'Luck': 5, 'Armor': 10, 'Weapon': 'Staff', 'Health': 245.0}])
    
    #check.summary()
#test_return_correct_dict_inside_list()


#Place test_calculate_health function here

def test_calculate_health():
    
    #test that the function does not change the lenght of the list provided as input parameter (5 different test cases required)
    
    check.equal(len(calculate_health(load_data('characters-test.csv', ('Occupation', 'AT')))), 3)
    
    check.equal(len(calculate_health(load_data('characters-test.csv', ('Personality', (10, 20))))), 17)
    
    check.equal(len(calculate_health(load_data('characters-test.csv', ('Stamina', 0.5)))), 19)
    
    check.equal(len(calculate_health(load_data('characters-test.csv', ('Weapon', 'Club')))), 5)
    
    check.equal(len(calculate_health(load_data('characters-test.csv', ('All', -1)))), 26)    
    
    
    #test that the function returns an empty list when it is called whith an empty list
    
    check.equal(calculate_health([]), [])
    
    
    #test that the function increments the number of keys of the dictionary inside the list by one (5 different test cases required)
    
    check.equal(len(calculate_health(load_data('characters-test.csv', ('Occupation', 'DB')))[0].keys()), 9)
    
    check.equal(len(calculate_health(load_data('characters-test.csv', ('Personality', (5, 20))))[0].keys()), 9)
    
    check.equal(len(calculate_health(load_data('characters-test.csv', ('Stamina', 0.4)))[0].keys()), 9)
    
    check.equal(len(calculate_health(load_data('characters-test.csv', ('Weapon', 'Dagger')))[0].keys()), 9)
    
    check.equal(len(calculate_health(load_data('characters-test.csv', ('All', 0)))[0].keys()), 10)     
    
    
    #test that the Health value is properly calculated (5 different test cases required)
    
    check.equal(calculate_health(load_data('characters-test.csv', ('Occupation', 'EB')))[0], {'Strength': 13, 'Weapon': 'Staff', 'Agility': 3, 'Stamina': 0.5, 'Intelligence': 7, 'Luck': 10, 'Armor': 8, 'Personality': 8, 'Health': 132.0})
    
    check.equal(calculate_health(load_data('characters-test.csv', ('Personality', (12, 20))))[-1], {'Occupation': 'WA', 'Strength': 17, 'Weapon': 'Dagger', 'Agility': 12, 'Stamina': 0.67, 'Intelligence': 7, 'Luck': 7, 'Armor': 11, 'Health': 236.5})
    
    check.equal(calculate_health(load_data('characters-test.csv', ('Stamina', 0.5)))[2], {'Occupation': 'EB', 'Strength': 13, 'Weapon': 'Dart', 'Agility': 13, 'Intelligence': 15, 'Luck': 12, 'Armor': 11, 'Personality': 8, 'Health': 291.5})
    
    check.equal(calculate_health(load_data('characters-test.csv', ('Weapon', 'Staff')))[0], {'Occupation': 'AT', 'Strength': 8, 'Agility': 7, 'Stamina': 0.67, 'Intelligence': 8, 'Luck': 2, 'Armor': 10, 'Personality': 11, 'Health': 125.0})
    
    check.equal(calculate_health(load_data('characters-test.csv', ('All', 0)))[-1], {'Occupation': 'WA', 'Strength': 12, 'Weapon': 'Club', 'Agility': 10, 'Luck': 6, 'Intelligence': 8, 'Stamina': 0.44, 'Armor': 10, 'Personality': 9, 'Health': 180.0})    
   
    
    #check.summary()
#test_calculate_health()


# Do NOT include a main script in your submission