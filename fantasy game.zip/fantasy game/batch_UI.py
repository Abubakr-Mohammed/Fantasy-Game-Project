# ECOR 1042 Lab 6 - Individual submission for batch_UI
from load_data import *
from sort import *
from histogram import *

# Update "" with your name (e.g., Rami Sabouni)
__author__ = "Dyson Katey Jumpah"

# Update "" with your student number (e.g., 100100100)
__student_number__ = "101265051"

# Update "" with your team (e.g. T-102, use the notation provided in the example)
__team__ = "T-15"

#==========================================#
# Place your script for your batch_UI after this line


"""
Reads commands from a text file and uses that as input commands to run the function. Returns appropriate values based on the command.

Preconditions: text file must be in the same location as the UI file.

"""
print('Please enter the name of the file where your commands are stored')
filename = str(input(
    ':'))

list_commands = []

batch_file = open(str(filename))


for line in batch_file:
    line = line.strip('\n').split(';')
    list_commands.append(line)


Firstline = list_commands[0]
Secondline = list_commands[1]
Thirdline = list_commands[2]

#------LOAD command-------------------------#
if Firstline[0] == 'L':
    filename = Firstline[1]
    key = Firstline[2]
    attribute = Firstline[3]
    load_tuple = (key, attribute)
    data = load_data(filename, load_tuple)
    print('Data loaded')


#------SORT command-------------------------#
if Secondline[0] == "S":

    filterer = Secondline[1]
    direction = Secondline[2]
    display = Secondline[3]
    sorted_data = sort(data, direction, filterer)
    print('Data sorted.')

    if display == "Y":
        print(sorted_data)
    else:
        print("<<<You selected not to display>>>")


#------HISTOGRAM command-------------------------#

if Thirdline[0] == "H":
    display_hist = Thirdline[1]
    histogram(data, display_hist)
    print(histogram)


